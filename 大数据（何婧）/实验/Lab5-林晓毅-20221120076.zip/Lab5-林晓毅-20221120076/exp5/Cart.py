import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, export_text
from sklearn.metrics import classification_report, accuracy_score

# 加载数据集
data = pd.read_csv("./BASKETS1n.csv")

# 添加 Healthy 列，标记健康食品购买者（同时购买 fruitveg 和 fish）
data['Healthy'] = data.apply(lambda row: 1 if row['fruitveg'] == 'T' and row['fish'] == 'T' else 0, axis=1)

# 设置所有用户相关信息字段为 None，保留 cardid 和 Healthy 字段
user_info_columns = ['pmethod', 'sex', 'homeown', 'income', 'age',
                     'fruitveg', 'freshmeat', 'dairy', 'cannedveg', 'cannedmeat',
                     'frozenmeal', 'beer', 'wine', 'softdrink', 'fish', 'confectionery']
data[user_info_columns] = None

# 再次加载数据，用于决策树训练
train_data = pd.read_csv("./BASKETS1n.csv")

# 添加 Healthy 列作为标签
train_data['Healthy'] = train_data.apply(lambda row: 1 if row['fruitveg'] == 'T' and row['fish'] == 'T' else 0, axis=1)

# 选择特征列作为输入，去除 'cardid' 和 'Healthy'
features = train_data[['pmethod', 'sex', 'homeown', 'income', 'age', 'freshmeat', 'dairy',
                       'cannedveg', 'cannedmeat', 'frozenmeal', 'beer', 'wine', 'softdrink', 'confectionery']]
# 将分类变量转为哑变量（one-hot encoding）
features = pd.get_dummies(features)

# 标签列
labels = train_data['Healthy']

# 拆分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=0.3, random_state=42)

# 创建CART决策树模型（使用Gini impurity）
clf = DecisionTreeClassifier(criterion="gini", min_samples_leaf=2, ccp_alpha=0.1,
                             class_weight='balanced', random_state=42)
clf.fit(X_train, y_train)

# 预测
y_pred = clf.predict(X_test)
print("分类报告：")
print(classification_report(y_test, y_pred, zero_division=0))
print("准确率：", accuracy_score(y_test, y_pred))

# 输出决策树的结构
tree_rules = export_text(clf, feature_names=list(features.columns))
print("\n决策树结构和节点指标：")
print(tree_rules)
