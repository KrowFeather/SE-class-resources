import pandas as pd
from mlxtend.frequent_patterns import fpgrowth, association_rules

# 加载数据集
data = pd.read_csv("./BASKETS1n.csv")

# 筛选出需要进行关联性分析的11个字段
basket_data = data[['fruitveg', 'freshmeat', 'dairy', 'cannedveg', 'cannedmeat',
                    'frozenmeal', 'beer', 'wine', 'softdrink', 'fish', 'confectionery']]

# 将数据转为布尔型（T/F）
basket_data = basket_data.apply(lambda col: col == 'T')

# 使用 FP-Growth 算法找到频繁项集
frequent_itemsets = fpgrowth(basket_data, min_support=0.1, use_colnames=True)

# 检查生成的频繁项集是否为空
if frequent_itemsets.empty:
    print("未找到满足支持度的频繁项集，请降低最小支持度。")
else:
    # 生成关联规则，设置最小置信度为80%
    rules = association_rules(frequent_itemsets, metric="confidence", min_threshold=0.8, num_itemsets=len(frequent_itemsets))

    # 格式化输出
    formatted_rules = rules[['antecedents', 'consequents', 'support', 'confidence']]
    formatted_rules.loc[:, 'support'] = formatted_rules['support'] * 100
    formatted_rules.loc[:, 'confidence'] = formatted_rules['confidence'] * 100

    # 打印结果
    print("关联规则：")
    print(formatted_rules)
