import jieba

with open('./data/text.txt', 'r', encoding='utf-8') as f:
    content = f.read()

# 使用 jieba 分词
sentences = [list(jieba.cut(line.strip())) for line in content.splitlines() if line.strip()]
from gensim.models import Word2Vec

# 训练 Word2Vec 模型
w2v_model = Word2Vec(sentences, vector_size=100, window=5, min_count=1, sg=0)
import torch
import torch.nn as nn

# 获取词汇表大小和词向量的维度
vocab_size = len(w2v_model.wv)
embedding_dim = w2v_model.vector_size

# 创建 PyTorch 的 nn.Embedding 层
embedding_layer = nn.Embedding(vocab_size, embedding_dim)

# 将 Gensim 的词向量复制到 nn.Embedding 层的权重中
embedding_layer.weight.data.copy_(torch.tensor(w2v_model.wv.vectors))
embedding_layer.weight.requires_grad = False

word_index = w2v_model.wv.key_to_index.get("美国", 0)
embedding_vector = embedding_layer(torch.tensor([word_index]))
print("Embedding vector for '美国':", embedding_vector)
