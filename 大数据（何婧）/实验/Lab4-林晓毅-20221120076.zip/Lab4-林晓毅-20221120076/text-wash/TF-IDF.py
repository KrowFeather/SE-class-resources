import jieba.analyse

with open('./data/text.txt', 'r', encoding='utf-8') as f:
    text = f.read()
    keywords = jieba.analyse.extract_tags(text, topK=20, withWeight=True)
    for item in keywords:
        print(item[0], item[1])
