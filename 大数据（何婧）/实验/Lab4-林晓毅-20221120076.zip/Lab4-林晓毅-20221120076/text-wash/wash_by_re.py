import re
with (open('./data/mid_comments_1.txt', 'r',encoding='utf-8') as f):
    text = f.read()
    text_res = re.sub(r'<.*?>|[,:;\'{}\[\]]', "", text)
    text_res = re.sub(r'\s+', ' ', text_res).strip().split(' ')
    print(text_res)
