import jieba
import time
cur = time.time()
with open('./data/text.txt','r',encoding='utf-8') as f:
    text = f.read()
    words = jieba.cut(text)
    for word in words:
        print(word,end=' ')
