import thulac
import time
thu = thulac.thulac(seg_only=True)
cur = time.time()
with open('./data/text.txt','r',encoding='utf-8') as f:
    text = f.read()
    text = thu.cut(text,text=True)
    print(text)
